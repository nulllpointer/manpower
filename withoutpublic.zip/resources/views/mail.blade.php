Name:    {{ $firstname }} {{ $lastname }}
Mobile: {{$mobile}}

Message:
{{$body}}


