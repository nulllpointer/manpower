<?php if(in_array("show", $actions)): ?>
    <a class="" title="<?php echo app('translator')->getFromJson('rapyd::rapyd.show'); ?>" href="<?php echo url('panel/'.$current_entity.'/'.$uri); ?>?show=<?php echo $id; ?>"><span class="glyphicon glyphicon-list-alt"> </span></a>
<?php endif; ?>
<?php if(in_array("modify", $actions)): ?>
    <a class="" title="<?php echo app('translator')->getFromJson('rapyd::rapyd.modify'); ?>" href="<?php echo url('panel/'.$current_entity.'/'.$uri); ?>?modify=<?php echo $id; ?>"><span class="fa fa-edit"> </span></a>
<?php endif; ?>
<?php if(in_array("delete", $actions)): ?>
    <a class="text-danger" title="<?php echo app('translator')->getFromJson('rapyd::rapyd.delete'); ?>" href="<?php echo url('panel/'.$current_entity.'/'.$uri); ?>?delete=<?php echo $id; ?>"><span class="glyphicon glyphicon-trash"> </span></a>
<?php endif; ?>
