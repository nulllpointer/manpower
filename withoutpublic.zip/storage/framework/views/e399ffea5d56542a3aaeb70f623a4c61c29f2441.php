<!DOCTYPE html>
<!--[if IE 8 ]>
<html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->

<!-- Mirrored from themesflat.com/html/corpbusiness/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Jan 2018 15:19:42 GMT -->
<head>
    <!-- Basic Page Needs -->
    <meta charset="UTF-8">
    <!--[if IE]>
    <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>ItgNEPAL</title>

    <meta name="author" content="themsflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Boostrap style -->
    <link rel="stylesheet" type="text/css" href="stylesheet/bootstrap.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="stylesheet/style.css">

    <!-- Reponsive -->
    <link rel="stylesheet" type="text/css" href="stylesheet/responsive.css">

</head>
<body class="home">

<div class="preloader">
    <div class="dizzy-gillespie"></div>
</div><!-- /.preloader -->

<div class="boxed">

    <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <section class="flat-row flat-about style3">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about style2">
                        <div class="about-title flat-row-title left">
                            <h2>International Trade Group Pvt Ltd</h2>
                        </div>
                        <div class="tab-about">
                            <ul class="tab-list">
                                <li class="active">Mission</li>
                                <li>Vision</li>
                                <li>Core Values</li>

                            </ul>
                            <div class="tab-content">
                                <div class="about-content">
                                    Our mission is to provide our
                                    clients and candidates with excellent recruitment services based on mutual
                                    trust and the highest professional standards driven by quality and cost
                                    consciousness. Our team of professionals entirely
                                    devoted in the mission to provide globally competitive manpower resources to the
                                    clients
                                    so that they can acquire gifted work force that will benefit their organization in
                                    every
                                    way possible We always look for cooperation for the
                                    supply of Nepalese manpower force to various countries. This will definitely
                                    strengthen the bridge between potential job seekers and generous employers and
                                    would also enhance our national development scheme.
<br>
                                    We are committed to connecting great companies with great employees and opening up
                                    opportunities for both by providing the highest quality of outsourced employment and
                                    human resource services. Success for our customers is reached by empowering them to
                                    focus on what they do best.


                                    <div class="check-box">
                                    </div>
                                </div><!-- /.about-content -->
                                <div class="about-content">
                                    <p>Our vision is to legally generate equal
                                        employment opportunities to various categories of labour force and professional
                                        personnel to overseas countries. We, in this organization, make all efforts to
                                        keep in touch with workers from the time of sending them abroad until their
                                        return after the completion of their project or in most cases, till their
                                        transfer to other countries as well.To assist qualified and talented Nepalese
                                        nationals to realize their full professional and personal aspirations by
                                        providing opportunities with professional employers who will value their skills
                                        and competence.
                                    </p>
                                    <p>Our organization also ensures that the workers will be adequately immunized and
                                        in case of serious injuries or sudden death, the compensation is made to their
                                        families through insurance companies. We always look for cooperation for the
                                        supply of Nepalese manpower force to various countries. This will definitely
                                        strengthen the bridge between potential job seekers and generous employers and
                                        would also enhance our national development scheme.</p>
                                </div><!-- /.about-content -->
                                <div class="about-content">
                                    <p><b>PEOPLE AND ETHICS</b>
                                        <br/>
                                        Our Most Important Assets
                                        n Search puts our clients and candidates first before anything else. We deal
                                        with people
                                        in
                                        our line of work and therefore, we are dedicated to searching for the best
                                        talents for
                                        our
                                        clients and to helping our candidates reach their maximum potential.

                                        <br>
                                        <b>HONESTY, INTEGRITY, TRANSPARENT COMMUNICATIONS</b>
                                        <br/>
                                        Customers, Employees & Vendors
                                        Our work at nSearch is strictly guided by a set of morals and principles that
                                        promise
                                        nothing but good and honest work.
                                        <br>

                                        <b> PERFORMANCE AND TEAMWORK</b>
                                        <br>
                                        We are a group of passionate individuals who are all about achieving our purpose
                                        in this
                                        industry. Teamwork is important for us because it allows us to work alongside
                                        one
                                        another in
                                        reaching that common goal.
                                        <br>

                                        <b> RELATIONSHIPS & TRUST</b>
                                        <br>
                                        We want to establish good and
                                        lasting
                                        relationships with our clients and candidates, and we believe that trust and
                                        determination
                                        are the ultimate recipe for success.
                                    </p>

                                </div><!-- /.about-content -->
                            </div>
                        </div><!-- /.wrap-about -->
                    </div><!-- /.about -->
                </div><!-- /.col-md-6 -->
                <div class="col-md-6">
                    <div class="about-image center">
                        <img class="imagebox-content" src="uploads/<?php echo e($aboutus[0]->imageabout); ?>"
                             style="    height: 517px;
    width: 764px;" max-wid alt="">
                    </div><!-- /.about -->
                </div><!-- /.col-md-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.flat-about -->

    
    <section class="flat-team">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="flat-row-title left">
                        <h2>Our Team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel-10">

                        <?php for($i = 2; $i < sizeOf($staffs); $i++): ?>

                            <div class="team-member">
                                <div class="team-image">
                                    <img src="uploads/<?php echo e($staffs[$i]->image); ?>" alt="<?php echo e($staffs[$i]->name); ?>"
                                         style="height: 300px; width: 270px">
                                </div>
                                <div class="team-content">
                                    <div class="option" style="font-size: 22px">
                                        <?php echo e($staffs[$i]->name); ?>/<?php echo e($staffs[$i]->department); ?>

                                    </div>
                                    <!-- /.social -->
                                </div><!-- /.team-content -->
                            </div>
                    <?php endfor; ?><!-- /.team-member -->

                    </div><!-- /.owl-carousel-10 -->
                </div>
            </div>
        </div>
    </section>




<!-- /.button-go-top -->
</div>

<!-- Javascript -->
<script type="text/javascript" src="javascript/jquery.min.js"></script>
<script type="text/javascript" src="javascript/bootstrap.min.js"></script>
<script type="text/javascript" src="javascript/waypoints.min.js"></script>
<script type="text/javascript" src="javascript/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="javascript/parallax.js"></script>
<script type="text/javascript" src="javascript/easing.js"></script>
<script type="text/javascript" src="javascript/owl.carousel.js"></script>
<script type="text/javascript" src="javascript/main.js"></script>

</body>

<!-- Mirrored from themesflat.com/html/corpbusiness/about by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 21 Jan 2018 15:19:53 GMT -->
</html>
<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>