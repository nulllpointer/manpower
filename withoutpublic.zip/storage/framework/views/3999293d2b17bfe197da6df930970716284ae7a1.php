Name:    <?php echo e($firstname); ?> <?php echo e($lastname); ?>

Mobile: <?php echo e($mobile); ?>


Message:
<?php echo e($body); ?>



