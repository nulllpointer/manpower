<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from envytheme.com/demo/pet-clinic/gallery-v1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 20 Jan 2018 19:41:02 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ItgNEPAL</title>
    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="assets/img/favicon-icon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Font-awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="assets/css/owl.carousel.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/datepicker.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- jQuery min js -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>

    <link rel="stylesheet" type="text/css" href="stylesheet/bootstrap.min.css">

    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
    <link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

    <!-- Fancybox style -->
    <link rel="stylesheet" type="text/css" href="stylesheet/jquery.fancybox.css">

    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="stylesheet/style.css">

    <!-- Reponsive -->
    <link rel="stylesheet" type="text/css" href="stylesheet/responsive.css">


</head>

<body class="home">

<!-- Preloader -->
<div class="preloader">
    <div class="dizzy-gillespie"></div>
</div><!-- /.preloader -->
<!-- End Preloader -->
<div class="boxed">




<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- End Start Top Header Area -->

    <!-- Start Main Menu Area -->

    <!-- SearchBox Modal -->
    <!-- End SearchBox Modal -->

    <div class="page-title parallax parallax7">
        <div class="overlay"></div>
        <div class="title-heading">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title-heading">
                            <h1>Company Legal Documents</h1>
                        </div>
                        
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.title-heading -->
    </div><!-- /.page-title -->


    <!-- Start Services Area -->
    <div class="content-block-area">
        <div class="container">
            <div class="row">

                <?php for($i = 0; $i < sizeOf($documents); $i++): ?>

                    <div class=" gallery-boxed">

                        <div class="gallery-item-one col-md-4 col-sm-6">
                            <div class="pic">
                                <img src="uploads/<?php echo e($documents[$i]->doc_url); ?>"
                                     alt="<?php echo e($documents[$i]->caption_heading); ?>" style="height: 200px;">
                                <ul class="lightbox-link">
                                    <li><a class="lightbox" href="uploads/<?php echo e($documents[$i]->doc_url); ?>"><i
                                                    class="fa fa-plus"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="gallery-content">
                                <h3 class="title"><?php echo e($documents[$i]->caption_heading); ?></h3>
                                
                            </div>
                          
                        </div>

                    </div>
                <?php endfor; ?>


                <div class="col-md-12 text-center">
                    <a href="#" id="loadmore" class="btn theme-btn">view more</a>
                </div>
            </div>
        </div>

    </div>
    <!-- End Services Area -->



<!-- Back Top top -->
    <a href="#content" class="back-to-top">Top</a>
    <!-- End Back Top top -->


</div>

<!-- Start Top Header Area -->

<!-- Bootstrap JS file -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Owl-Carousel JS file -->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- Magnific Popup JS file -->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!-- Mixitup JS file -->
<script src="assets/js/mixitup.min.js"></script>
<!-- Swiper JS file -->
<script src="assets/js/swiper.jquery.min.js"></script>
<!-- Datepicker JS file -->
<script src="assets/js/datepicker.js"></script>
<!-- WOW JS file -->
<script src="assets/js/wow.min.js"></script>
<!-- Isotop JS JS file -->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!-- Waypoints JS file -->
<script src="assets/js/waypoints.min.js"></script>
<!-- Counter JS file -->
<script src="assets/js/jquery.counterup.min.js"></script>
<!-- RipplesJS -->
<script src="assets/js/jquery.ripples-min.js"></script>
<!-- YTPlayer JS -->
<script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
<!-- Jarallax JS -->
<script src="assets/js/jarallax.min.js"></script>
<!-- Parsley JS -->
<script src="assets/js/parsley.min.js"></script>
<!-- jQuery Google Map JS file -->
<script src="assets/js/jquery.googlemap.js"></script>
<!-- Google Map api -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC0jIY1DdGJ7yWZrPDmhCiupu_K2En_4HY"></script>
<!-- Custom JS file -->
<script src="assets/js/active.js"></script>
<script type="text/javascript" src="javascript/jquery.min.js"></script>
<script type="text/javascript" src="javascript/bootstrap.min.js"></script>
<script type="text/javascript" src="javascript/waypoints.min.js"></script>
<script type="text/javascript" src="javascript/parallax.js"></script>
<script type="text/javascript" src="javascript/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="javascript/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="javascript/easing.js"></script>

<script type="text/javascript" src="javascript/jquery.fancybox.js"></script>
<script type="text/javascript" src="javascript/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="javascript/owl.carousel.js"></script>
<script type="text/javascript" src="javascript/jquery-countTo.js"></script>

<script type="text/javascript" src="javascript/main.js"></script>

<!-- Revolution Slider -->
<script type="text/javascript" src="revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="revolution/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="revolution/js/slider.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="revolution/js/extensions/revolution.extension.video.min.js"></script>

</body>

<!-- Mirrored from envytheme.com/demo/pet-clinic/gallery-v1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 20 Jan 2018 19:42:05 GMT -->
</html>
<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>