<?php
namespace App\Observers;

use App\aboutus;

class aboutusObserver
{
    
    /**
     * Listen to the aboutus creating event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function creating(aboutus $aboutus)
    {
        //code...
    }

     /**
     * Listen to the aboutus created event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function created(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus updating event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function updating(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus updated event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function updated(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus saving event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function saving(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus saved event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function saved(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus deleting event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function deleting(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus deleted event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function deleted(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus restoring event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function restoring(aboutus $aboutus)
    {
        //code...
    }

    /**
     * Listen to the aboutus restored event.
     *
     * @param  aboutus  $aboutus
     * @return void
     */
    public function restored(aboutus $aboutus)
    {
        //code...
    }
}