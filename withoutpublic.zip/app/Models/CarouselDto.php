<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CarouselDto
{
    //carousel

    public $picUrl;
    public $altName;
    public $captionHeading;
    public $captionDesc;
    public $btnText;
    public $btnUrl;
}
