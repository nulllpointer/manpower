<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Block extends Model
{
    //carousel
    protected $table = 'block';
    public $timestamps = false;
  }
